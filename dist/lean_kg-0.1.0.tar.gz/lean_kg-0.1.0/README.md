
# Lean-KG

A Python library for generating and visualizing Mathlib4 as a directed multigraph embedded in Euclidean N-space.

## Installation

You can install the package using pip.
